#ifndef COMUN_H_INCLUDED
#define COMUN_H_INCLUDED

#include <iostream>
#include <string.h>
#include <fstream>
#include <iomanip>
#include <cstdlib>

using namespace std;

typedef char cadena[150];
#define INCREMENTO 4
#define cls system ("cls");
#define pause system ("pause");

#include "GestorClientes.h"
#include "GestorVehiculos.h"
#include "GestorAlquiler.h"


#endif // COMUN_H_INCLUDED
